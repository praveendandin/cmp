$(function () {
    $(".itmesList .product-item").slice(0, 4).show();
    $("#loadMore").on('click', function (e) {
        e.preventDefault();
        $(".itmesList .product-item:hidden").slice(0, 4).slideDown();
    });

    // carousel slider
    $("#owl-demo").owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        autoplay: true,
        autoplayHoverPause: true,
        items: 1,   
        
   
    });

    // adding class on owl-carousel controller
        $('.owl-controls').addClass('container');
        $('.owl-controls .owl-buttons').remove();
		
	//language 
	$(".lang-en").click(function() {
        $("body").removeClass("arabic-language");

    });
	$(".lang-ar").click(function() {
        $("body").addClass("arabic-language");
    });

});


