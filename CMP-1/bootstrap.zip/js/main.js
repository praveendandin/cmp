

$(document).ready(function(){
    $('.module-button').click(function(){
        $('.module-link').toggle('module-active');
    })
});

